import 'package:equatable/equatable.dart';
import '../../../domain/entities/note.dart';

abstract class NotesEvent extends Equatable {
  const NotesEvent();
  @override
  List<Object?> get props => [];
}

/// Fetch all notes
class FetchNotes extends NotesEvent {}

/// Add a new note
class AddNoteEvent extends NotesEvent {
  final Note note;
  const AddNoteEvent(this.note);

  @override
  List<Object?> get props => [note];
}

/// Update an existing note
class UpdateNoteEvent extends NotesEvent {
  final Note note;
  const UpdateNoteEvent(this.note);

  @override
  List<Object?> get props => [note];
}

/// Delete a note by ID
class DeleteNoteEvent extends NotesEvent {
  final int id;
  const DeleteNoteEvent(this.id);

  @override
  List<Object?> get props => [id];
}
