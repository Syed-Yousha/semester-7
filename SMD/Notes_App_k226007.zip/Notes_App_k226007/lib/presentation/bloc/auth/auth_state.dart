import 'package:equatable/equatable.dart';

abstract class AuthState extends Equatable {
  const AuthState();
  @override
  List<Object?> get props => [];
}

/// Initial state (before checking anything)
class AuthInitial extends AuthState {}

/// While checking login / performing login
class AuthLoading extends AuthState {}

/// User is authenticated
class AuthAuthenticated extends AuthState {}

/// User is not authenticated
class AuthUnauthenticated extends AuthState {}

/// Something went wrong
class AuthError extends AuthState {
  final String message;
  const AuthError(this.message);

  @override
  List<Object?> get props => [message];
}
