
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'presentation/screens/splash_screen.dart';
import 'presentation/bloc/auth/auth_bloc.dart';
import 'presentation/bloc/notes/notes_bloc.dart';
import 'data/repositories/note_repository_impl.dart';
import 'data/datasources/note_datasource.dart';

void main() {
  runApp(const MyNotesApp());
}

class MyNotesApp extends StatelessWidget {
  const MyNotesApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Notes Application',
      theme: ThemeData.light(),
      darkTheme: ThemeData.dark(),
      themeMode: ThemeMode.system,
      home: const _DependencyInitializer(),
    );
  }
}

class _DependencyInitializer extends StatelessWidget {
  const _DependencyInitializer();

  @override
  Widget build(BuildContext context) {
  final notesSource = NoteDataSource();
  final notesRepo = NoteRepositoryImpl(noteSource: notesSource);

    return MultiBlocProvider(
      providers: [
        BlocProvider<AuthBloc>(
          create: (context) => AuthBloc(),
        ),
        BlocProvider<NotesBloc>(
          create: (context) => NotesBloc(repository: notesRepo),
        ),
      ],
      child: const SplashScreen(),
    );
  }
}