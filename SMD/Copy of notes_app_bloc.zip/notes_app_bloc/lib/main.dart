import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'presentation/screens/splash_screen.dart';
import 'presentation/bloc/auth/auth_bloc.dart';
import 'presentation/bloc/notes/notes_bloc.dart';
import 'data/repositories/note_repository_impl.dart';
import 'data/datasources/note_datasource.dart';

void main() {
  runApp(const NotesApp());
}

class NotesApp extends StatelessWidget {
  const NotesApp({super.key});

  @override
  Widget build(BuildContext context) {
    // Initialize data layer
    final noteDataSource = NoteDataSource();
    final noteRepository = NoteRepositoryImpl(dataSource: noteDataSource);

    return MultiBlocProvider(
      providers: [
        // AuthBloc handles login/logout
        BlocProvider<AuthBloc>(
          create: (_) => AuthBloc(),
        ),
        // NotesBloc handles all CRUD operations
        BlocProvider<NotesBloc>(
          create: (_) => NotesBloc(repository: noteRepository),
        ),
      ],
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'Notes App',
        theme: ThemeData.light(), // light mode
        darkTheme: ThemeData.dark(), // dark mode
        themeMode: ThemeMode.system, // follow system preference
        home: const SplashScreen(),
      ),
    );
  }
}
