import '../repositories/note_repository.dart';

class DeleteNote {
  final NoteRepository repository;

  DeleteNote(this.repository);

  /// Delete note by ID
  Future<void> call(int id) async {
    await repository.deleteNote(id);
  }
}
