import '../entities/note.dart';
import '../repositories/note_repository.dart';

class AddNote {
  final NoteRepository repository;

  AddNote(this.repository);

  /// Add a new note
  Future<void> call(Note note) async {
    await repository.createNote(note);
  }
}
