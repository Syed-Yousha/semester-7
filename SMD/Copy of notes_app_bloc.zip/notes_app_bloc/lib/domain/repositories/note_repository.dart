// lib/domain/repositories/note_repository.dart

import 'package:notes_app_bloc/domain/entities/note.dart';

/// Contract for Note-related operations.
/// The data layer will implement this interface.
abstract class NoteRepository {
  /// Fetch all notes.
  Future<List<Note>> getNotes();

  /// Fetch single note by ID.
  Future<Note> getNote(int id);

  /// Create a new note.
  Future<Note> createNote(Note note);

  /// Update an existing note.
  Future<Note> updateNote(Note note);

  /// Delete a note by ID.
  Future<void> deleteNote(int id);
}
