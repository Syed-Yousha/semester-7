// lib/data/repositories/note_repository_impl.dart

import '../../domain/entities/note.dart';
import '../../domain/repositories/note_repository.dart';
import '../datasources/note_datasource.dart';
import '../models/note_model.dart';

class NoteRepositoryImpl implements NoteRepository {
  final NoteDataSource dataSource;

  NoteRepositoryImpl({required this.dataSource});

  @override
  Future<List<Note>> getNotes() async {
    try {
      final noteModels = await dataSource.fetchNotes();
      return noteModels.map((e) => e.toEntity()).toList();
    } catch (e) {
      throw Exception('Failed to fetch notes: $e');
    }
  }

  @override
  Future<Note> getNote(int id) async {
    try {
      final noteModels = await dataSource.fetchNotes();
      final noteModel = noteModels.firstWhere(
        (n) => n.id == id,
        orElse: () => throw Exception('Note not found'),
      );
      return noteModel.toEntity();
    } catch (e) {
      throw Exception('Failed to fetch note: $e');
    }
  }

  @override
  Future<Note> createNote(Note note) async {
    try {
      final noteModel = NoteModel.fromEntity(note);
      final newNote = await dataSource.addNote(noteModel);
      return newNote.toEntity();
    } catch (e) {
      throw Exception('Failed to create note: $e');
    }
  }

  @override
  Future<Note> updateNote(Note note) async {
    try {
      final noteModel = NoteModel.fromEntity(note);
      final updatedNote = await dataSource.updateNote(noteModel);
      return updatedNote.toEntity();
    } catch (e) {
      throw Exception('Failed to update note: $e');
    }
  }

  @override
  Future<void> deleteNote(int id) async {
    try {
      await dataSource.deleteNote(id);
    } catch (e) {
      throw Exception('Failed to delete note: $e');
    }
  }
}
