import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/note_model.dart';

class NoteDataSource {
  final List<NoteModel> _notes = [];

  // Simulate fetching notes from a mock REST API
  Future<List<NoteModel>> fetchNotes() async {
    try {
      final response =
          await http.get(Uri.parse('https://jsonplaceholder.typicode.com/posts'));

      if (response.statusCode == 200) {
        final List<dynamic> data = jsonDecode(response.body);
        // Map jsonplaceholder posts to NoteModel
        final notes = data.map((json) {
          return NoteModel(
            id: json['id'],
            title: json['title'],
            description: json['body'],
            createdAt: DateTime.now(),
          );
        }).toList();

        // Update local in-memory list for add/update/delete simulation
        _notes.clear();
        _notes.addAll(notes);

        return notes;
      } else {
        throw Exception('Failed to fetch notes');
      }
    } catch (e) {
      throw Exception('Error fetching notes: $e');
    }
  }

  // Add, update, delete remain same with simulated delay
  Future<NoteModel> addNote(NoteModel note) async {
    await Future.delayed(const Duration(seconds: 1));
    final newNote = NoteModel(
      id: _notes.isEmpty ? 1 : (_notes.last.id ?? 0) + 1,
      title: note.title,
      description: note.description,
      createdAt: DateTime.now(),
    );
    _notes.add(newNote);
    return newNote;
  }

  Future<NoteModel> updateNote(NoteModel note) async {
    await Future.delayed(const Duration(seconds: 1));
    final index = _notes.indexWhere((n) => n.id == note.id);
    if (index == -1) throw Exception('Note not found');
    _notes[index] = note;
    return note;
  }

  Future<void> deleteNote(int id) async {
    await Future.delayed(const Duration(seconds: 1));
    _notes.removeWhere((n) => n.id == id);
  }
}
