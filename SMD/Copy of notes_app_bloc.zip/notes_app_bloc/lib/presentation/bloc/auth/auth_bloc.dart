import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'auth_event.dart';
import 'auth_state.dart';

class AuthBloc extends Bloc<AuthEvent, AuthState> {
  final FlutterSecureStorage _storage = const FlutterSecureStorage();
  static const String _tokenKey = 'token';

  AuthBloc() : super(AuthInitial()) {
    on<CheckAuthEvent>(_onCheckAuth);
    on<LoginRequested>(_onLoginRequested);
    on<LogoutRequested>(_onLogoutRequested);
  }

  /// Check if token exists on app start
  Future<void> _onCheckAuth(
      CheckAuthEvent event, Emitter<AuthState> emit) async {
    emit(AuthLoading());
    final token = await _storage.read(key: _tokenKey);
    if (token != null) {
      emit(AuthAuthenticated());
    } else {
      emit(AuthUnauthenticated());
    }
  }

  /// Handle login
  Future<void> _onLoginRequested(
      LoginRequested event, Emitter<AuthState> emit) async {
    emit(AuthLoading());
    try {
      // Simulate API delay
      await Future.delayed(const Duration(seconds: 2));

      // Mock login check
      if (event.email == 'test@test.com' && event.password == '1234') {
        await _storage.write(key: _tokenKey, value: 'mock_token');
        emit(AuthAuthenticated());
      } else {
        emit(const AuthError('Invalid email or password'));
        emit(AuthUnauthenticated());
      }
    } catch (e) {
      emit(AuthError('Login failed: $e'));
      emit(AuthUnauthenticated());
    }
  }

  /// Handle logout
  Future<void> _onLogoutRequested(
      LogoutRequested event, Emitter<AuthState> emit) async {
    emit(AuthLoading());
    await _storage.delete(key: _tokenKey);
    emit(AuthUnauthenticated());
  }
}
